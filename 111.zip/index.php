<?php
session_start();
include 'includes/db.php';

// Fetch slider images from DB
$sliderImages = [];
$result = $conn->query("SELECT image_path FROM home_slider_images ORDER BY uploaded_at DESC");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $imagePath = $row['image_path'];

        // Allow only valid image formats
        $ext = strtolower(pathinfo($imagePath, PATHINFO_EXTENSION));
        $allowedExts = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];

        if (in_array($ext, $allowedExts)) {
            $sliderImages[] = $imagePath;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Md. Naimul Islam | Portfolio</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    :root {
      --primary: #1e2a78;
      --secondary: #f0f0f0;
      --light: #ffffff;
      --dark: #121212;
      --accent: #3c91e6;

      --bg-color: #f0f4ff;
      --text-color: var(--dark);
      --box-color: var(--light);
    }

    body.dark-mode {
      --bg-color: #121212;
      --text-color: #e0e0e0;
      --box-color: #1f1f1f;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background: var(--bg-color);
      color: var(--text-color);
      text-align: center;
      transition: background 0.3s ease, color 0.3s ease;
    }

    header {
      padding: 40px 20px 20px 20px;
      background-color: var(--primary);
      color: var(--light);
      position: relative;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    header h1 {
      margin: 0;
      font-size: 2.5rem;
    }

    header p {
      margin-top: 10px;
      font-size: 1.1rem;
      color: #dce3f5;
    }

    /* Separate container for slider */
    .slider-container {
      max-width: 922px;
      margin: 40px auto 20px auto;
      background-color: var(--box-color);
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      border-radius: 12px;
      padding: 10px 10px 20px 10px;
      position: relative;
    }

    #slider {
      width: 100%;
      height: 600px;
      position: relative;
      overflow: hidden;
      border-radius: 10px;
      background: #f0f0f0;
      box-shadow: 0 8px 16px rgba(0,0,0,0.15);
    }

    #slider img {
      width: 100%;
      height: 100%;
      position: absolute;
      left: 0; top: 0;
      opacity: 0;
      transition: opacity 1s ease-in-out;
      object-fit: cover;
      user-select: none;
    }

    #slider img.active {
      opacity: 1;
      z-index: 10;
    }

    /* Arrow Buttons */
    .slider-arrow {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      background: rgba(30, 42, 120, 0.7);
      color: white;
      border: none;
      padding: 10px 15px;
      cursor: pointer;
      border-radius: 50%;
      font-size: 24px;
      transition: background 0.3s ease;
      user-select: none;
      z-index: 20;
    }

    .slider-arrow:hover {
      background: var(--accent);
    }

    #arrow-left {
      left: 15px;
    }

    #arrow-right {
      right: 15px;
    }

    /* Description container separate */
    .description-container {
      max-width: 900px;
      margin: 20px auto 40px auto;
      padding: 20px;
      background-color: var(--box-color);
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      border-radius: 12px;
      text-align: justify;
      font-size: 1rem;
      line-height: 1.6;
    }

    nav {
      max-width: 900px;
      margin: 0 auto 40px auto;
      text-align: center;
    }

    nav a {
      display: inline-block;
      margin: 10px;
      padding: 12px 24px;
      background-color: var(--light);
      color: var(--primary);
      border: 2px solid var(--primary);
      border-radius: 8px;
      font-weight: 600;
      text-decoration: none;
      transition: all 0.3s ease;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    nav a:hover {
      background-color: var(--accent);
      color: #fff;
      border-color: var(--accent);
      transform: translateY(-2px);
    }

    footer {
      margin-top: 40px;
      padding: 20px;
      background-color: var(--primary);
      color: var(--light);
      font-size: 0.9rem;
    }

    /* Toggle Switch */
    .theme-toggle {
      position: absolute;
      top: 20px;
      right: 20px;
    }

    .toggle-btn {
      background-color: #fff;
      border: none;
      border-radius: 20px;
      padding: 8px 16px;
      cursor: pointer;
      font-weight: 600;
      font-size: 0.9rem;
      color: #333;
      transition: background 0.3s ease, color 0.3s ease;
    }

    .toggle-btn:hover {
      background-color: var(--accent);
      color: #fff;
    }

    @media (max-width: 960px) {
      .slider-container, .description-container, nav {
        max-width: 95%;
      }
      #slider {
        height: 250px;
      }
      .slider-arrow {
        font-size: 18px;
        padding: 8px 12px;
      }
    }
  </style>
</head>
<body>
  <header>
    <div class="theme-toggle">
      <button class="toggle-btn" onclick="toggleTheme()">Toggle Theme</button>
    </div>
    <h1>Md. Naimul Islam</h1>
    <p>Final-Year CSE Student at AIUB | AI • Embedded Systems • Full-Stack Development</p>
  </header>

  <nav>
    <a href="pages/projects.php">Projects</a>
    <a href="pages/blogs.php">Blogs</a>
    <a href="contact.php">Contact</a>
    <a href="resume.php">Resume</a>
    <a href="admin/login.php">Admin Login</a>
  </nav>



  <!-- Description Container -->
  <div class="description-container">
    <p><strong>I am Md. Naimul Islam</strong>, a final-year student of Computer Science and Engineering at the American International University-Bangladesh (AIUB). I have a strong interest in leveraging technology to solve real-world problems, particularly in the fields of artificial intelligence, machine learning, embedded systems, and full-stack web development. With a solid academic foundation and practical exposure to diverse technical domains, I strive to build intelligent, scalable, and user-focused digital solutions.</p>

    <p>My core strengths include analytical thinking, adaptability, and a constant desire to learn and innovate. I am particularly enthusiastic about exploring how AI and data-driven insights can optimize processes in industries such as retail, automation, and smart systems. I am also deeply interested in UI/UX design and system architecture, and I aim to continue expanding my expertise through research, collaboration, and meaningful contributions to the tech community.</p>
  </div>
  <!-- Slider Container -->
  <div class="slider-container">
    <div id="slider">
      <?php foreach ($sliderImages as $index => $imgPath): ?>
        <img src="<?php echo htmlspecialchars($imgPath); ?>" alt="Slide <?php echo $index + 1; ?>" class="<?php echo ($index === 0) ? 'active' : ''; ?>">
      <?php endforeach; ?>

      <button class="slider-arrow" id="arrow-left" aria-label="Previous Slide">&#10094;</button>
      <button class="slider-arrow" id="arrow-right" aria-label="Next Slide">&#10095;</button>
    </div>
  </div>

  <footer>
    &copy; <?php echo date("Y"); ?> Md. Naimul Islam. All Rights Reserved.
  </footer>

  <script>
    // Theme toggle
    function toggleTheme() {
      document.body.classList.toggle('dark-mode');
      localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
    }

    // Persist theme on reload
    window.addEventListener('DOMContentLoaded', () => {
      const savedTheme = localStorage.getItem('theme');
      if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
      }
    });

    // Slider functionality
    const slides = document.querySelectorAll('#slider img');
    const leftArrow = document.getElementById('arrow-left');
    const rightArrow = document.getElementById('arrow-right');
    let currentIndex = 0;
    let slideInterval;

    function showSlide(index) {
      slides.forEach((slide, i) => {
        slide.classList.toggle('active', i === index);
      });
    }

    function nextSlide() {
      currentIndex = (currentIndex + 1) % slides.length;
      showSlide(currentIndex);
    }

    function prevSlide() {
      currentIndex = (currentIndex - 1 + slides.length) % slides.length;
      showSlide(currentIndex);
    }

    leftArrow.addEventListener('click', () => {
      prevSlide();
      resetInterval();
    });

    rightArrow.addEventListener('click', () => {
      nextSlide();
      resetInterval();
    });

    function startInterval() {
      slideInterval = setInterval(nextSlide, 4000);
    }

    function resetInterval() {
      clearInterval(slideInterval);
      startInterval();
    }

    startInterval();
  </script>
</body>
</html>
