<?php
include 'includes/db.php';
echo "Database connection successful!";
?>
