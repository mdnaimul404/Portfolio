<?php
session_start();
include '../includes/db.php'; // adjust path if needed

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Prepare and execute query
    $stmt = $conn->prepare("SELECT id, username, password FROM admin_users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();

    $result = $stmt->get_result();
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Verify password using password_verify
        if (password_verify($password, $user['password'])) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $user['username'];
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid credentials!";
        }
    } else {
        $error = "Invalid credentials!";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap');

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Inter', Arial, sans-serif;
            background: #f4f6f8;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            color: #222;
            flex-direction: column;
        }

        .login-box {
            background: #ffffff;
            padding: 40px 35px 50px;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0, 37, 77, 0.1);
            max-width: 400px;
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            animation: fadeInUp 0.6s ease forwards;
        }

        @keyframes fadeInUp {
            0% {
                opacity: 0;
                transform: translateY(20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-box h2 {
            margin: 0 0 25px;
            font-weight: 700;
            font-size: 2rem;
            color: #1b2a49;
            letter-spacing: 1px;
            text-align: center;
        }

        .login-box form {
            width: 100%;
            display: flex;
            flex-direction: column;
        }

        .login-box input[type="text"],
        .login-box input[type="password"] {
            padding: 14px 18px;
            margin-bottom: 20px;
            font-size: 1rem;
            border: 1.5px solid #ced4da;
            border-radius: 8px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
            outline-offset: 2px;
            outline-color: transparent;
            background: #fafafa;
            color: #222;
        }

        .login-box input[type="text"]:focus,
        .login-box input[type="password"]:focus {
            border-color: #2c7be5;
            box-shadow: 0 0 8px #74a9f8;
            outline-color: #74a9f8;
            background: #fff;
        }

        .login-box button {
            padding: 14px 0;
            background: linear-gradient(90deg, #2c7be5 0%, #1a53a0 100%);
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 1.15rem;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 10px 30px rgba(44, 123, 229, 0.4);
            transition: background 0.3s ease, transform 0.2s ease;
        }

        .login-box button:hover {
            background: linear-gradient(90deg, #1a53a0 0%, #2c7be5 100%);
            transform: scale(1.04);
        }

        .error-msg {
            color: #e03131;
            font-weight: 600;
            margin-top: -10px;
            margin-bottom: 10px;
            text-align: center;
        }

        .back-btn {
            margin-top: 20px;
            padding: 12px 25px;
            background-color: #e9ecef;
            border: 2px solid #2c7be5;
            border-radius: 8px;
            color: #2c7be5;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-size: 1rem;
            text-align: center;
            width: 100%;
            max-width: 400px;
        }

        .back-btn:hover {
            background-color: #2c7be5;
            color: white;
        }

        /* Responsive adjustments */
        @media (max-width: 480px) {
            .login-box {
                padding: 30px 25px 40px;
                max-width: 100%;
            }

            .login-box h2 {
                font-size: 1.6rem;
                margin-bottom: 20px;
            }

            .login-box input[type="text"],
            .login-box input[type="password"],
            .login-box button,
            .back-btn {
                font-size: 1rem;
                padding: 12px 14px;
            }
        }

        @media (min-width: 481px) and (max-width: 768px) {
            .login-box {
                max-width: 350px;
            }
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>Admin Login</h2>
        <form method="POST" action="">
            <input type="text" name="username" placeholder="Username" required autofocus>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <?php if (!empty($error)): ?>
            <div class="error-msg"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <a href="../index.php" class="back-btn">← Back to Home</a>
    </div>
</body>
</html>
