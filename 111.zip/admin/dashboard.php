<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

include '../includes/db.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            flex-direction: column;
            position: relative;
        }
        .dashboard {
            background: #fff;
            padding: 40px 50px;
            border-radius: 12px;
            max-width: 960px;
            width: 100%;
            box-shadow: 0 0 25px rgba(0,0,0,0.12);
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            grid-gap: 30px 20px;
            text-align: center;
            margin-bottom: 80px;
        }

        .dashboard h1 {
            grid-column: span 3;
            margin-bottom: 30px;
            color: #333;
        }
        .dashboard a {
            background: #3498db;
            color: #fff;
            font-size: 16px;
            width: 8cm;     /* fixed width */
            height: 2cm;    /* fixed height */
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            box-shadow: 0 5px 12px rgba(52, 152, 219, 0.4);
            transition: background-color 0.3s ease, transform 0.2s ease;
            /* No aspect-ratio needed here */
            margin: 0 auto;
        }
        .dashboard a:hover {
            background: #216bb5;
            transform: translateY(-4px);
            box-shadow: 0 8px 20px rgba(33, 107, 181, 0.6);
        }
        /* Responsive */
        @media (max-width: 768px) {
            .dashboard {
                max-width: 100%;
                padding: 20px;
                grid-template-columns: repeat(2, 1fr);
                grid-gap: 15px 10px;
            }
            .dashboard h1 {
                grid-column: span 2;
                font-size: 1.8rem;
            }
            .dashboard a {
                width: 90%;  /* responsive width */
                height: 2.2cm; /* keep approx height */
            }
        }
        @media (max-width: 480px) {
            .dashboard {
                grid-template-columns: 1fr;
                grid-gap: 12px;
            }
            .dashboard h1 {
                grid-column: auto;
            }
            .dashboard a {
                width: 100%;
                height: 2.4cm;
                font-size: 14px;
            }
        }

        /* Fixed Back to Home Button */
        .back-home-btn {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #e74c3c; /* red-ish color */
            color: #fff;
            border: none;
            padding: 14px 30px;
            border-radius: 30px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 6px 15px rgba(231, 76, 60, 0.5);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
            z-index: 999;
            width: 180px;
            text-align: center;
        }

        .back-home-btn:hover {
            background-color: #c0392b;
            box-shadow: 0 8px 20px rgba(192, 57, 43, 0.7);
        }
    </style>
</head>
<body>

<div class="dashboard">
    <h1>Welcome, MD. NAIMUL ISLAM</h1>

    <a href="manage-projects.php">📁 Manage Projects</a>
    <a href="manage-blogs.php">📝 Manage Blogs</a>
    <a href="manage-messages.php">📬 View Contact Messages</a>

    <!-- Group: User & Settings -->
    <!--<a href="manage-users.php">👥 Manage Users</a>
    <a href="settings.php">⚙️ Settings</a>-->
    
    <!-- Group: Resume, Comments, Images -->
    <a href="manage-resume.php">📄 Manage Resume & Certificates</a>
    <a href="manage_comments.php">💬 Manage Comments</a>
    <a href="image_upload.php">🖼️ Manage Images</a>

    <a href="logout.php">🔒 Logout</a>
</div>

</body>
</html>
